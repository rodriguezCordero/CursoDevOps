export const environment = {
  production: true,
  basePath: 'http://localhost:8080'
};
